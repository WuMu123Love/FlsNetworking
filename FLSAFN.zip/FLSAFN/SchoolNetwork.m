//
//  SchoolNetwork.m
//  SchoolNetworking
//
//  Created by 天立泰 on 17/4/26.
//  Copyright © 2017年 天立泰. All rights reserved.
//

#import "SchoolNetwork.h"

@implementation SchoolNetwork
+ (void)backDataForHTTP:(NSString *)httpStr httpMethod:(NSString *)httpMethod parameters:(NSDictionary *)paraDic success:(Success)success failure:(Failure)failure{
//    __block typeof(self)weakSelf = self;
    NSString * httpHolder = httpStr;
    NSURL * url = [NSURL URLWithString:httpHolder];
    NSMutableURLRequest * request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:httpMethod];//设置请求方式
    
    if (paraDic.count > 0) {
        NSMutableArray * paraArray = [NSMutableArray array];
        [paraDic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            NSString * keyAndValueString = [NSString stringWithFormat:@"%@=%@",key,obj];
            [paraArray addObject:keyAndValueString];
        }];
        NSString * paraString = [paraArray componentsJoinedByString:@"&"];
        //设置请求体
        request.HTTPBody = [paraString dataUsingEncoding:NSUTF8StringEncoding];
    }
    [request setTimeoutInterval:20];//设置超时时间
    NSURLSession * session = [NSURLSession sharedSession];
    NSURLSessionDataTask * task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error) {
            if (failure) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    failure(error);
                });
            }
        }else{
            if (success) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    success(data);
                });
            }
        
        }
    }];
    
    [task resume];
}

+ (void)HTTP:(NSString *)httpStr httpMethod:(NSString *)httpMethod parameters:(NSDictionary *)paraDic success:(Success)success failure:(Failure)failure{
        __block typeof(self)weakSelf = self;
    NSString * httpHolder = httpStr;
    NSURL * url = [NSURL URLWithString:httpHolder];
    NSMutableURLRequest * request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:httpMethod];//设置请求方式
    
    if (paraDic.count > 0) {
        NSMutableArray * paraArray = [NSMutableArray array];
        [paraDic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            NSString * keyAndValueString = [NSString stringWithFormat:@"%@=%@",key,obj];
            [paraArray addObject:keyAndValueString];
        }];
        NSString * paraString = [paraArray componentsJoinedByString:@"&"];
        //设置请求体
        request.HTTPBody = [paraString dataUsingEncoding:NSUTF8StringEncoding];
    }
    [request setTimeoutInterval:30];//设置超时时间
    NSURLSession * session = [NSURLSession sharedSession];
    NSURLSessionDataTask * task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error) {
            if (failure) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    failure(error);
                });
            }
        }else{
            if (success) {
                NSDictionary * dataDic = [weakSelf backDictionarywithData:data];
//                NSString * str = @"{code:1,msg:验证成功,userName:<null>,pwd:,userId:<NULL>}";
//                NSData * dataStr = [str dataUsingEncoding:NSUTF8StringEncoding];

//                NSDictionary * dataDic = [SchoolNetwork backDictionarywithData:dataStr];

                dispatch_async(dispatch_get_main_queue(), ^{
                    success(dataDic);
                });
            }
            
        }
    }];
    
    [task resume];
    
}

//{code:1,msg:验证成功}
+ (NSDictionary *)backDictionarywithData:(NSData *)responseData{
//    __weak typeof(self) weakSelf = self;
    
    NSMutableArray * keyArray = [NSMutableArray array];
    NSMutableArray * valueArray = [NSMutableArray array];
    
    NSString * deletStr1 = @"{";
    NSString * deleteStr2 = @"}";
    NSString * dataStr = [[NSString alloc]initWithData:responseData encoding:NSUTF8StringEncoding];
    LFLog(@"%@",dataStr);
    NSRange range1 = [dataStr rangeOfString:deletStr1];
    NSRange range2 = [dataStr rangeOfString:deleteStr2];
    NSMutableString * dataMUTString = [NSMutableString stringWithString:dataStr];
    [dataMUTString deleteCharactersInRange:range2];
    [dataMUTString deleteCharactersInRange:range1];
    NSArray * dataStrArray = [dataMUTString componentsSeparatedByString:@","];
    [dataStrArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        NSString * itemStr = [SchoolNetwork transToStringWithObject:obj];
        NSArray * itemArray = [itemStr componentsSeparatedByString:@":"];
        for (int i = 0; i < itemArray.count ; i++) {
            if (i == 0) {
                NSString * keyStr = [SchoolNetwork transToStringWithObject:itemArray[i]];
                [keyArray addObject:keyStr];
            }else if (i == 1){
                 NSString * valueStr = [SchoolNetwork transToStringWithObject:itemArray[i]];
                [valueArray addObject:valueStr];
            }
            
        }
        
    }];
    
    NSMutableDictionary * dataDictionary = [NSMutableDictionary dictionary];
    for (int i = 0; i < dataStrArray.count; i ++) {
        [dataDictionary setObject:valueArray[i] forKey:keyArray[i]];
    }
    return dataDictionary;
}


+ (NSString *)transToStringWithObject:(id)object {
    NSString *string = [NSString stringWithFormat:@"%@",object];
    if ([string isEqualToString:@"<null>"] || [string isEqualToString:@"<NULL>"] || string == nil ||string.length == 0) {
        return @" ";
    }else {
        return [NSString stringWithFormat:@"%@",string];
    }
}




@end
