//
//  FLSPicModle.m
//  FLS_AFNetworking
//
//  Created by 天立泰 on 16/8/19.
//  Copyright © 2016年 天立泰. All rights reserved.
//

#import "FLSPicModle.h"

@implementation FLSPicModle

- (NSString *)description{
    
    return [NSString stringWithFormat:@"<%@ : %p> \n{picName : %@ \n pic : %@ \n}", [self class], self,self.picName, self.pic];
    
}

@end
