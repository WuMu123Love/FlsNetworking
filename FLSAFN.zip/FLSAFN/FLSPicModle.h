//
//  FLSPicModle.h
//  FLS_AFNetworking
//
//  Created by 天立泰 on 16/8/19.
//  Copyright © 2016年 天立泰. All rights reserved.
//

#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN


@interface FLSPicModle : NSObject


/*
 * 上传的图片的名字
 */
@property (nonatomic, copy)NSString * picName;

/*
 * 上传的图片
 */
@property (nonatomic, strong, nullable) UIImage *pic;

/*
 * 上传的二进制文件
 */
@property (nonatomic, strong) NSData *picData;

/*
 * 上传的资源Url
 */
@property (nonatomic, copy) NSString *url;

@end
NS_ASSUME_NONNULL_END