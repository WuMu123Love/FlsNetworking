//
//  FLSNetworking.m
//  FLS_AFNetworking
//
//  Created by 天立泰 on 16/8/19.
//  Copyright © 2016年 天立泰. All rights reserved.
//

#import "FLSNetworking.h"
#import "FLSPicModle.h"
#import "UIImage+HDExtension.h"
#import "AFNetworking.h"

@implementation FLSNetworking

HDSingletonM(FLSNetworking);//单例实现
/**
 * 网络监测 （在什么网络状态）
 *  @param unknown          未知网络
 *  @param reachable        无网络
 *  @param reachableViaWWAN 蜂窝数据网
 *  @param reachableViaWiFi WiFi网络
 */
- (void)networkStatusUnknown:(Unknown)unknown reachable:(Reachable)reachable reachableViaWWAN:(ReachableViaWWAN)reachableViaWWAN reachableViaWiFi:(ReachableViaWIFI)reachableViaWiFi{
    
    //创建网络检测者
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        //监测到不同网络情况
        
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                unknown();
                break;
            case AFNetworkReachabilityStatusNotReachable:
                reachable();
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                reachableViaWWAN();
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                reachableViaWiFi();
                break;
            default:
                break;
        }
        
    }];
    
    //开始监听网络状况
    [manager startMonitoring];
}

/**
 *  封装的get请求
 *
 *  @param URLString  请求的链接
 *  @param parameters 请求的参数
 *  @param success    请求成功回调
 *  @param failure    请求失败回调
 */

- (void)GEt:(NSString *)URLString parameters:(NSDictionary *)parameters success:(Success)success failure:(Failure)failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    NSMutableSet * contentTypes = [[NSMutableSet alloc] initWithSet:manager.responseSerializer.acceptableContentTypes];
    [contentTypes addObject:@"text/html"];
    [contentTypes addObject:@"text/plain"];
    
    manager.responseSerializer.acceptableContentTypes = self.acceptableContentTypes;

    manager.requestSerializer.timeoutInterval = (self.timeOutInterval ?self.timeOutInterval:20);
    //显示网络活跃标志
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    [manager GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //请求数据成功
        if (success) {
            success(responseObject);
        }
        //隐藏网络活动的标志
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
        
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    }];
}

/**
 *  封装的get请求 处理特殊字符
 *
 *  @param URLString  请求的链接
 *  @param parameters 请求的参数
 *  @param success    请求成功回调
 *  @param failure    请求失败回调
 */

- (void)GETresolveSpecialCharacters:(NSString *)URLString parameters:(NSDictionary *)parameters success:(Success)success failure:(Failure)failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableSet * contentTypes = [[NSMutableSet alloc] initWithSet:manager.responseSerializer.acceptableContentTypes];
    [contentTypes addObject:@"text/html"];
    [contentTypes addObject:@"text/plain"];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", nil];
    
    manager.requestSerializer.timeoutInterval = (self.timeOutInterval ?self.timeOutInterval:20);
    //显示网络活跃标志
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    [manager GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //请求数据成功
        //获得的json先转换成字符串
        NSString *receiveStr = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        if (receiveStr && ![receiveStr isEqualToString:@""]) {
            //保留回车和换行
//            receiveStr = [receiveStr stringByReplacingOccurrencesOfString:@"\r" withString:@"TFR"];
//            receiveStr = [receiveStr stringByReplacingOccurrencesOfString:@"\n" withString:@"TFN"];
//            receiveStr = [receiveStr stringByReplacingOccurrencesOfString:@"\t" withString:@"TFT"];
            receiveStr = [receiveStr stringByReplacingOccurrencesOfString:@"\r" withString:@"\\r"];
            receiveStr = [receiveStr stringByReplacingOccurrencesOfString:@"\n" withString:@"\\n"];
            receiveStr = [receiveStr stringByReplacingOccurrencesOfString:@"\t" withString:@"\\t"];
            NSCharacterSet *controlChars = [NSCharacterSet controlCharacterSet];
            NSRange range = [receiveStr rangeOfCharacterFromSet:controlChars];
            if (range.location != NSNotFound)
            {
                NSMutableString *mutable = [NSMutableString stringWithString:receiveStr];
                while (range.location != NSNotFound)
                {
                    [mutable deleteCharactersInRange:range];
                    range = [mutable rangeOfCharacterFromSet:controlChars];
                }
                receiveStr = mutable;
               
            }
        }
        
        //字符串再生成NSData
        NSData * data = [receiveStr dataUsingEncoding:NSUTF8StringEncoding];
       
        //再解析
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if (success) {
            success(jsonDict);
        }
        //隐藏网络活动的标志
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
        
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    }];
}



/**
 *  封装的POST请求
 *
 *  @param URLString  请求的链接
 *  @param parameters 请求的参数
 *  @param success    请求成功回调
 *  @param failure    请求失败回调
 */
- (void)POST:(NSString *)URLString parameters:(NSDictionary *)parameters success:(Success)success failure:(Failure)failure{
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    NSMutableSet * contentTypes = [[NSMutableSet alloc] initWithSet:manager.responseSerializer.acceptableContentTypes];
    [contentTypes addObject:@"text/html"];
    [contentTypes addObject:@"text/plain"];
    manager.responseSerializer.acceptableContentTypes = self.acceptableContentTypes;
    manager.requestSerializer.timeoutInterval = (self.timeOutInterval ? self.timeOutInterval : 20);
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    NSURLSessionDataTask *task =
    
    [manager POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //请求成功
        if (success) {
            success(responseObject);
        }
        
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //请求失败
        if (failure) {
            failure(error);
        }
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];

    }];
    
    self.task = task;
}


/**
 *  封装POST图片上传(多张图片) // 可扩展成多个别的数据上传如:mp3等
 *
 *  @param URLString  请求的链接
 *  @param parameters 请求的参数
 *  @param picArray   存放图片模型(HDPicModle)的数组
 *  @param progress   进度的回调
 *  @param success    发送成功的回调
 *  @param failure    发送失败的回调
 */
- (void)POST:(NSString*)URLString parameters:(nonnull NSDictionary *)parameters andPicArray:(nonnull NSArray<FLSPicModle *> *)picArray progress:(Progress)progress success:(Success)success failure:(Failure)failure{
    

    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    
    manager.responseSerializer.acceptableContentTypes  = self.acceptableContentTypes;
    manager.requestSerializer.timeoutInterval = (self.timeOutInterval ? self.timeOutInterval:20);
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];//请求不使用AFN默认转换，保持原有数据
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];//响应不使用AFN默认转换，保持原有数据
    [manager POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        
        NSInteger count = picArray.count;
        NSString *fileName = @"";
        NSData * data = [NSData data];
        for (int i = 0; i<count; i++) {
            @autoreleasepool {
                FLSPicModle *picModel = picArray[i];
                fileName = [NSString stringWithFormat:@"pic%02d.jpg",i];
                
                /***
                 *压缩图片然后再上传（1.0代表无损 0~~1.0区间）
                 */
                data = UIImageJPEGRepresentation(picModel.pic, 1.0);
                CGFloat precent = self.picSize/(data.length/1024.0);
                if (precent>1) {
                    precent = 1.0;
                }
                data = nil;
                data = UIImageJPEGRepresentation(picModel.pic, precent);
                [formData appendPartWithFileData:data name:picModel.picName fileName:fileName mimeType:@"image/jpeg"];
                data = nil;
                picModel.pic = nil;
                
                
                
            }
        }
        
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
        if (progress) {
            progress(uploadProgress);
        }
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        
        if (success) {
            success(responseObject);
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
    
    
}


/**
 *  封装POST图片上传(单张图片) // 可扩展成单个别的数据上传如:mp3等
 *
 *  @param URLString  请求的链接
 *  @param parameters 请求的参数
 *  @param picModle   上传的图片模型
 *  @param progress   进度的回调
 *  @param success    发送成功的回调
 *  @param failure    发送失败的回调
 */
- (void)POST:(NSString *)URLString parameters:(NSDictionary *)parameters andPic:(FLSPicModle *)picModel progress:(Progress)progress success:(Success)success failure:(Failure)failure{
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = self.acceptableContentTypes;
    manager.requestSerializer.timeoutInterval = (self.timeOutInterval ? self.timeOutInterval:20);
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];// 请求不使用AFN默认转换,保持原有数据
    manager.responseSerializer =[AFHTTPResponseSerializer serializer];// 响应不使用AFN默认转换,保持原有数据
    [manager POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        /**
         *  压缩图片然后再上传(1.0代表无损 0~~1.0区间)
         */
        
        NSData  *data = UIImageJPEGRepresentation(picModel.pic, 1.0);
        CGFloat precent = self.picSize/(data.length/1024.0);
        if (precent >1) {
            precent= 1.0;
        }
        data = nil;
        data = UIImageJPEGRepresentation(picModel.pic, precent);
        NSString *fileName = [NSString stringWithFormat:@"%@.jpg",picModel.picName];
        [formData appendPartWithFileData:data name:picModel.picName fileName:fileName mimeType:@"image/ipeg"];
        
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
        if (progress) {
            progress(uploadProgress);
        }
        
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (success) {
            success(responseObject);
        }
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        
        if (failure) {
            failure(error);
        }
        
    }];
    
    
}
/**
 *  封装POST上传url资源
 *
 *  @param URLString  请求的链接
 *  @param parameters 请求的参数
 *  @param picModle   上传的图片模型(资源的url地址)
 *  @param progress   进度的回调
 *  @param success    发送成功的回调
 *  @param failure    发送失败的回调
 */

- (void)POST:(NSString *)URLString parameters:(NSDictionary *)parameters andPicUrl:(FLSPicModle *)picModel progress:(Progress)progress success:(Success)success failure:(Failure)failure{
    
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = self.acceptableContentTypes;
    manager.requestSerializer.timeoutInterval = (self.timeOutInterval ? self.timeOutInterval:20);
    
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];// 请求不使用AFN默认转换,保持原有数据
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];// 响应不使用AFN默认转换,保持原有数据
    [manager POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSString *fileName = [NSString stringWithFormat:@"%@.jpg",picModel.picName];
        
        //根据本地路径获取URL（相册等资源上传）
        NSURL * url = [NSURL fileURLWithPath:picModel.url];// [NSURL URLWithString:picModle.url] 可以换成网络的图片在上传
        [formData appendPartWithFileURL:url name:picModel.picName fileName:fileName mimeType:@"application/octet-stream" error:nil];
        
        
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            progress(uploadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
    
}

/**
 *  下载
 *
 *  @param URLString       请求的链接
 *  @param progress        进度的回调
 *  @param destination     返回URL的回调
 *  @param downLoadSuccess 发送成功的回调
 *  @param failure         发送失败的回调
 */
- (NSURLSessionDownloadTask *)downLoadWithURL:(NSString *)URLString progress:(Progress)progress destination:(Destination)destination downLoadSuccess:(DownLoadSuccess)downLoadSuccess failure:(Failure)failure{
    
    
    AFHTTPSessionManager  *manager = [AFHTTPSessionManager manager];
    
    NSURL * url = [NSURL URLWithString:URLString];
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    
    //下载任务
    NSURLSessionDownloadTask * task = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        if (progress) {
            progress(downloadProgress);
        }
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        if (destination) {
            return destination(targetPath,response);
        }else{
            return nil;
        }
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        if (error) {
            failure(error);
        }else{
            downLoadSuccess(response,filePath);
        }
    }];
    
    
    
    //可似乎启动任务
    [task resume];
    return task;
    
    
}

#pragma mark  网络判断

/**
 监测网络

 @return 是否有网络
 */
-(BOOL)requestBeforeJudgeConnect {
    struct sockaddr zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sa_len = sizeof(zeroAddress);
    zeroAddress.sa_family = AF_INET;
    SCNetworkReachabilityRef defaultRouteReachability =
    SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    BOOL didRetrieveFlags =
    SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    if (!didRetrieveFlags) {
        NSLog(@"Error. Count not recover network reachability flags\n");
        return NO;
    }
    BOOL isReachable = flags & kSCNetworkFlagsReachable;
    BOOL needsConnection = flags & kSCNetworkFlagsConnectionRequired;
    BOOL isNetworkEnable  =(isReachable && !needsConnection) ? YES : NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible =isNetworkEnable;/*  网络指示器的状态： 有网络 ： 开  没有网络： 关  */
    });
    return isNetworkEnable;
}

@end
