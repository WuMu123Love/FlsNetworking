//
//  SchoolNetwork.h
//  SchoolNetworking
//
//  Created by 天立泰 on 17/4/26.
//  Copyright © 2017年 天立泰. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
typedef void(^ _Nullable Success )(id responseObject);
typedef void(^ _Nullable Failure)(NSError * error);

@interface SchoolNetwork : NSObject


/*
 * 源数据请求
 */
+ (void)backDataForHTTP:(NSString *)httpStr httpMethod:(NSString *)httpMethod parameters:(NSDictionary *)paraDic success:(Success)success failure:(Failure)failure;

/*
 * 适配校园网后台接口数据请求
 */

+ (void)HTTP:(NSString *)httpStr httpMethod:(NSString *)httpMethod parameters:(NSDictionary *)paraDic success:(Success)success failure:(Failure)failure;

@end
NS_ASSUME_NONNULL_END
